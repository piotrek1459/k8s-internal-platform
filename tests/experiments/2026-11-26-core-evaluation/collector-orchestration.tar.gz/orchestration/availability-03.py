import sys,json,time,os,subprocess
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'tools')
from run import Experiment
from common import write_json
root=Path.cwd();deadline=time.monotonic()+2400
while not (root/'pulls-03/summary.json').exists():
 if time.monotonic()>deadline:raise TimeoutError('Previous matrices incomplete')
 time.sleep(2)
args=SimpleNamespace(plan=root/'plan-v2.json',release_manifest=root/'release.json',state=root/'access.json',ca=root/'ca.crt',
 management_url='https://platform.home.arpa:8443',address='192.168.68.227',chart=root/'embedded-chart',output=root/'availability-01',
 kubeconfig='/etc/rancher/k3s/k3s.yaml',tools='/usr/local/lib/k8s-internal-platform')
exp=Experiment(args);exchange=root/'exchange-availability';exchange.mkdir(mode=0o700,exist_ok=True);os.chown(exchange,1000,1000)
try:
 app,accepted=exp.api_create('availability',lan=True);exp.api.poll(accepted['operationId'])
 current=exp.api.get('/apps/'+app)
 start=time.time()+15
 write_json(exchange/'job.json',{'jobID':'availability-01','url':current['access']['url']+'version','managementURL':'https://platform.home.arpa:8443/readyz','startEpochSeconds':start,'seconds':75,'rate':5})
 os.chown(exchange/'job.json',1000,1000)
 timeline=[]
 def stage(name,**details):
  timeline.append({'stage':name,'epochSeconds':time.time(),**details});write_json(exp.folder/'timeline.json',timeline)
 time.sleep(max(0,start+15-time.time()));stage('update-submitted')
 accepted=exp.api.mutate(app,'PATCH',image=exp.images['v2']);exp.api.poll(accepted['operationId']);stage('update-ready',operationID=accepted['operationId'])
 time.sleep(max(0,start+35-time.time()))
 pods=exp.host.kube('-n','platform-system','get','pods','-l','app.kubernetes.io/name=platform')['items']
 pods=[p for p in pods if any(c['image']==exp.images['platform'] for c in p['spec']['containers'])]
 if len(pods)!=1:raise ValueError('No unique matching broker Pod')
 pod=pods[0];name=pod['metadata']['name'];uid=pod['metadata']['uid']
 stage('broker-delete-submitted',podUID=uid)
 body=json.dumps({'apiVersion':'v1','kind':'DeleteOptions','preconditions':{'uid':uid}})
 result=subprocess.run([exp.host.kubectl,'--kubeconfig',exp.host.kubeconfig,'delete','--raw','/api/v1/namespaces/platform-system/pods/'+name,'-f','-'],input=body,capture_output=True,text=True,timeout=30)
 if result.returncode:raise RuntimeError('Guarded broker replacement refused')
 deadline=time.monotonic()+120
 attempts=[]
 while time.monotonic()<deadline:
  replacement=exp.host.kube('-n','platform-system','get','pods','-l','app.kubernetes.io/name=platform')['items']
  replacement=[p for p in replacement if p['metadata']['uid']!=uid and not p['metadata'].get('deletionTimestamp') and p['status'].get('containerStatuses') and all(c['ready'] for c in p['status']['containerStatuses'])]
  if len(replacement)==1:
   try:
    value=exp.api.get('/apps/'+app)
    if value['activeOperationId']:raise ValueError('Unexpected active operation')
    break
   except (RuntimeError,TimeoutError) as error:attempts.append({'epochSeconds':time.time(),'errorClass':type(error).__name__})
  time.sleep(.25)
 else:raise TimeoutError('Replacement identity/readiness/session verification exceeded budget')
 stage('broker-ready',replacementPodUID=replacement[0]['metadata']['uid'],APIProbeFailures=attempts)
 stage('original-session-valid-after-replacement')
 time.sleep(max(0,start+80-time.time()))
 for filename in ('app-summary.json','management-summary.json'):
  if not (exchange/filename).exists():raise RuntimeError('Availability client result missing')
  write_json(exp.folder/filename,json.loads((exchange/filename).read_text()))
 exp.api_delete(app)
 write_json(exp.folder/'complete.json',{'originalApplicationsRetained':exp.application_identities()==exp.original_apps,'owned':exp.owned,'humanOperatorTime':None})
 print('AVAILABILITY_COMPLETE',flush=True)
finally:exp.close()
