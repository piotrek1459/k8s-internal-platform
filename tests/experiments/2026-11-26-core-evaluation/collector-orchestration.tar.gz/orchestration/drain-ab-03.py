import sys,json,time,os,copy,urllib.error
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'tools')
from run import Experiment
from common import write_json,canonical_hash
root=Path.cwd();deadline=time.monotonic()+300
while not (root/'profile-validation-02/summary.json').exists():
 if time.monotonic()>deadline:raise TimeoutError('Profile validation incomplete')
 time.sleep(1)
args=SimpleNamespace(plan=root/'validation-plan.json',release_manifest=root/'release.json',state=root/'access.json',ca=root/'ca.crt',
 management_url='https://platform.home.arpa:8443',address='192.168.68.227',chart=root/'embedded-chart',output=root/'drain-ab-03',
 kubeconfig='/etc/rancher/k3s/k3s.yaml',tools='/usr/local/lib/k8s-internal-platform')
exp=Experiment(args);exchange=root/'exchange-drain-03';exchange.mkdir(mode=0o700,exist_ok=True);os.chown(exchange,1000,1000)
results=[]
try:
 exp.prepare()
 for condition,chart in [('control',root/'embedded-chart'),('candidate',root/'candidate-chart')]:
  release=f'eval-{exp.run_id}-{condition}';hostname=release+'.'+exp.api.application_domain
  def values(version):
   result=copy.deepcopy(exp.base_values);result['appId']=release
   result['image']['repository'],result['image']['digest']=exp.images[version].split('@')
   result['ingress']['enabled']=True;result['ingress']['className']='platform-private';result['ingress']['hostname']=hostname
   path=exp.folder/(condition+'-'+version+'.json');write_json(path,result);return path
  r=exp.helm('install',release,chart,'-n','platform-apps','-f',values('v1'),'--wait','--timeout','120s')
  record=exp.remember_release(release)
  if r.returncode:raise RuntimeError('Owned drain trial installation failed')
  def check(expected):
   end=time.monotonic()+30
   while True:
    try:
     with exp.api.http.open('https://'+hostname+':8443/version',timeout=3) as response:body=json.load(response)
     if body['version']==expected:return
    except (urllib.error.HTTPError,urllib.error.URLError,TimeoutError,ConnectionError) as error:
     if hasattr(error,'close'):error.close()
    if time.monotonic()>end:raise TimeoutError('Drain trial HTTP did not converge')
    time.sleep(.2)
  check('v1');start=time.time()+12
  write_json(exchange/'job.json',{'jobID':condition,'url':'https://'+hostname+':8443/version','startEpochSeconds':start,'seconds':75,'rate':5})
  os.chown(exchange/'job.json',1000,1000)
  timeline=[]
  for index,(offset,version) in enumerate([(15,'v2'),(35,'v1'),(55,'v2')],1):
   time.sleep(max(0,start+offset-time.time()))
   entry={'stage':'update-'+str(index),'version':version,'submittedEpochSeconds':time.time()};timeline.append(entry);write_json(exp.folder/(condition+'-timeline.json'),timeline)
   r=exp.helm('upgrade',release,chart,'-n','platform-apps','-f',values(version),'--wait','--timeout','120s')
   if r.returncode:raise RuntimeError('Drain trial update failed')
   check(version);entry['verifiedEpochSeconds']=time.time()
   pods=exp.host.app_pods(release)
   live=[p['spec']['containers'][0].get('lifecycle') for p in pods]
   if condition=='candidate' and any(x!={'preStop':{'sleep':{'seconds':5}}} for x in live):raise ValueError('Candidate native sleep action missing')
   entry['liveLifecycle']=live;write_json(exp.folder/(condition+'-timeline.json'),timeline)
  time.sleep(max(0,start+78-time.time()));receipt=exchange/(condition+'-summary.json');end=time.monotonic()+180
  while not receipt.exists() and time.monotonic()<end:time.sleep(.5)
  if not receipt.exists():raise RuntimeError('Drain trial client data absent')
  observed=json.loads(receipt.read_text());write_json(exp.folder/(condition+'-client-summary.json'),observed)
  results.append({'condition':condition,'storedChartSHA256':canonical_hash(record['chart']),'storedConfig':record['config'],'client':observed,'timeline':timeline})
  exp.helm_delete(release)
 write_json(exp.folder/'summary.json',{'cases':results,'originalApplicationsRetained':exp.application_identities()==exp.original_apps,'owned':exp.owned,
 'scope':'Native direct-Helm source-chart experiment; published v0.1.10 runtime remains unchanged'})
 print('DRAIN_AB_COMPLETE',flush=True)
finally:exp.close()
