import sys,json,time,urllib.error
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'tools')
from run import Experiment
from common import write_json,canonical_hash
root=Path.cwd();deadline=time.monotonic()+1200
while not (root/'availability-01/complete.json').exists() or not (root/'derived-preset.json').exists():
 if time.monotonic()>deadline:raise TimeoutError('Prerequisite measurements/profile absent')
 time.sleep(2)
preset=json.loads((root/'derived-preset.json').read_text())
plan=json.loads((root/'plan-v2.json').read_text());plan['resourceCandidate']=preset;plan['repetitions']=1;plan['methodOrder']=[['api','helm']]
plan['validationScope']='Explicit derived profile: native API, two ready replicas, actual HTTPS; no replacement for published-default acceptance'
write_json(root/'validation-plan.json',plan)
args=SimpleNamespace(plan=root/'validation-plan.json',release_manifest=root/'release.json',state=root/'access.json',ca=root/'ca.crt',
 management_url='https://platform.home.arpa:8443',address='192.168.68.227',chart=root/'embedded-chart',output=root/'profile-validation-02',
 kubeconfig='/etc/rancher/k3s/k3s.yaml',tools='/usr/local/lib/k8s-internal-platform')
exp=Experiment(args);results=[]
try:
 for workload in ('go','nginx'):
  public=workload=='nginx';image=exp.plan['publicImage'] if public else exp.images['v1']
  app,accepted=exp.api_create('profile-'+workload,image=image,lan=True,public=public,replicas=2);exp.api.poll(accepted['operationId'])
  pods=exp.host.app_pods(app)
  expected={'requests':{'cpu':preset['cpuRequest'],'memory':preset['memoryRequest']},'limits':{'cpu':preset['cpuLimit'],'memory':preset['memoryLimit']}}
  if len(pods)!=2 or any(p['spec']['containers'][0]['resources']!=expected or not p['status']['containerStatuses'][0]['ready'] for p in pods):raise ValueError('Live reference-profile replicas/resources differ')
  current=exp.api.get('/apps/'+app)
  end=time.monotonic()+30;probes=[]
  while True:
   try:
    with exp.api.http.open(current['access']['url']+('' if public else 'version'),timeout=3) as response:body=response.read(1<<20);status=response.code
    valid=status==200 and (b'Welcome to nginx!' in body if public else json.loads(body)['version']=='v1')
   except urllib.error.HTTPError as error:status=error.code;valid=False;error.close()
   probes.append({'epochSeconds':time.time(),'status':status,'expectedContent':valid})
   if valid:break
   if time.monotonic()>end:raise TimeoutError('Reference-profile HTTPS convergence exceeded budget')
   time.sleep(.2)
  containers=exp.host.containers(app)
  for c in containers:c['lifetimeMemoryPeakBytes']=int((Path(c['cgroup'])/'memory.peak').read_text())
  results.append({'workload':workload,'appID':app,'actualHTTPS':200,'replicas':2,'resources':expected,'containers':containers,'HTTPSProbes':probes})
  exp.api_delete(app)
 write_json(exp.folder/'summary.json',{'passed':True,'profile':preset,'validationPlanSHA256':canonical_hash(plan),'cases':results,
 'originalApplicationsRetained':exp.application_identities()==exp.original_apps,'owned':exp.owned,'publishedDefaultValidationPending':True})
 print('PRESET_VALIDATION_COMPLETE',flush=True)
finally:exp.close()
