import sys,json,time,traceback,os
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime
sys.path.insert(0,'tools')
from api import API
from common import write_json
from run import Experiment
root=Path.cwd();deadline=time.monotonic()+3600
while not (root/'resources-04/complete.json').exists():
    if time.monotonic()>deadline:raise TimeoutError('Resource series incomplete; post-processing refused')
    time.sleep(2)
from pulls import run as pull_run
api=API('https://platform.home.arpa:8443',root/'access.json',root/'ca.crt','192.168.68.227','0.1.10')
try:
    api.login();observations=[]
    for row in json.loads((root/'lifecycle-01/timings.json').read_text()):
        if row['method']!='api':continue
        if not row.get('operation'):continue
        op=api.get('/operations/'+row['operation'])
        record={'operationID':op['id'],'stage':row['stage'],'repetition':row['repetition'],'state':op['state'],
                'events':[{'at':e['at'],'stage':e['stage']} for e in op['events']]}
        if row['stage']=='unhealthy-v3-and-restoration':
            stages={e['stage']:datetime.fromisoformat(e['at'].replace('Z','+00:00')) for e in op['events']}
            record['backendFailureDetectionSeconds']=(stages['restoring']-stages['applying']).total_seconds()
            record['backendVerifiedRestorationSeconds']=(stages['restored']-stages['restoring']).total_seconds()
        observations.append(record)
    write_json(root/'lifecycle-01/operation-events.json',observations)
finally:api.close()
args=SimpleNamespace(plan=root/'plan-v2.json',release_manifest=root/'release.json',state=root/'access.json',ca=root/'ca.crt',
 management_url='https://platform.home.arpa:8443',address='192.168.68.227',chart=root/'embedded-chart',output=root/'pulls-03',
 kubeconfig='/etc/rancher/k3s/k3s.yaml',tools='/usr/local/lib/k8s-internal-platform')
exp=Experiment(args)
try:pull_run(exp,True)
finally:exp.close()
print('POST_SERIES_COMPLETE',flush=True)
