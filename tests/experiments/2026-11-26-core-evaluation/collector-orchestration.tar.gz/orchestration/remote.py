import json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/'ssh.json').read_text())
def remote(script):
    return subprocess.run(['ssh','-S',CFG['control'],'-oBatchMode=yes',CFG['host'],'bash -s'],input=script,text=True,capture_output=True,timeout=60)
def upload(source,target):
    subprocess.run(['scp','-q','-oControlPath='+CFG['control'],str(source),CFG['host']+':'+target],check=True)
def download(source,target):
    subprocess.run(['scp','-q','-r','-oControlPath='+CFG['control'],CFG['host']+':'+source,str(target)],check=True)
