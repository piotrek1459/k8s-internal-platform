import sys,json,time
from pathlib import Path
sys.path.insert(0,'tests/evaluation')
from load import run
from remote import remote,upload
root=Path('.local/evaluation-v0110/drain-client-03');root.mkdir(mode=0o700,exist_ok=True)
seen=set();deadline=time.monotonic()+600
while len(seen)<2 and time.monotonic()<deadline:
 r=remote('cat platform-evaluation-v0110/exchange-drain-03/job.json 2>/dev/null')
 if r.returncode:time.sleep(1);continue
 job=json.loads(r.stdout)
 if job['jobID'] in seen:time.sleep(1);continue
 delay=job['startEpochSeconds']-time.time()
 if delay>0:time.sleep(delay)
 if time.time()-job['startEpochSeconds']>2:raise RuntimeError('Late drain-trial client start')
 result=run(job['url'],root/job['jobID'],Path('.local/pi-acceptance/native-v018/pki/ca.crt'),'192.168.68.227',rate=5,seconds=75,warmup=0,expected_version=('v1','v2'))
 upload(root/job['jobID']/'summary.json','platform-evaluation-v0110/exchange-drain-03/'+job['jobID']+'-summary.json')
 seen.add(job['jobID']);print(job['jobID'],result['successful'],result['requests'],result['clientSchedulingValid'],flush=True)
print('DRAIN_CLIENT_COMPLETE',flush=True)
