"""Independent verified-LAN readiness observation before SSH reconnection."""
import json
import socket
import ssl
import time
import urllib.error
import urllib.request
from pathlib import Path

root = Path(__file__).resolve().parent
original = socket.getaddrinfo
def resolve(host, port, *args, **kwargs):
    return original('192.168.68.227' if host == 'platform.home.arpa' else host, port, *args, **kwargs)
socket.getaddrinfo = resolve
context = ssl.create_default_context(cafile=str(root.parent / 'native-v018/pki/ca.crt'))
http = urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=context))
def ready():
    try:
        with http.open('https://platform.home.arpa:8443/readyz', timeout=3) as response:
            value = json.load(response)
            return response.code == 200 and value.get('status') == 'ready' and value.get('cluster') == 'available'
    except (urllib.error.URLError, TimeoutError, ConnectionError, json.JSONDecodeError):
        return False
assert ready(), 'Initial verified HTTPS readiness failed'
(root / 'reboot-monitor.ready').write_text('ready\n')
started = time.monotonic()
lost = None
observations = []
while time.monotonic() - started < 360:
    ok = ready()
    elapsed = round(time.monotonic() - started, 3)
    observations.append({'seconds': elapsed, 'ready': ok})
    if not ok and lost is None:
        lost = time.monotonic()
    if ok and lost is not None:
        result = {'directVerifiedHTTPS': True, 'outageObserved': True,
            'readyAfterMonitorSeconds': elapsed,
            'secondsAfterFirstUnavailable': round(time.monotonic() - lost, 3),
            'SSHOrManualServiceStartBeforeReady': False, 'observations': observations}
        (root / 'automatic-reboot-readiness.json').write_text(json.dumps(result, indent=2) + '\n')
        print('Verified HTTPS recovered before SSH/manual startup:', elapsed, 'seconds', flush=True)
        break
    time.sleep(.5)
else:
    raise TimeoutError('Verified HTTPS readiness did not recover within six minutes')
