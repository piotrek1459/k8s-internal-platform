"""Read-only, whitelisted retention evidence; no credential or Secret payload export."""
import hashlib
import json
import sqlite3
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, 'tools')
from host import Host

host = Host('/etc/rancher/k3s/k3s.yaml', '/usr/local/lib/k8s-internal-platform')
def get(kind, name=None, namespace='platform-system'):
    args = ['-n', namespace, 'get', kind]
    if name:
        args.append(name)
    return host.kube(*args)
def meta(value):
    return {k: value['metadata'].get(k) for k in ('name', 'namespace', 'uid', 'creationTimestamp')}
def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

pvc = get('pvc', 'platform-metadata')
pv = host.kube('get', 'pv', pvc['spec']['volumeName'])
folder = Path(pv['spec'].get('hostPath', pv['spec'].get('local', {}))['path'])
databases = list(folder.glob('*.db'))
assert len(databases) == 1
db = sqlite3.connect('file:' + str(databases[0]) + '?mode=ro', uri=True)
db.execute('BEGIN')
critical = {}
for table in ('applications', 'revisions', 'operations', 'operation_events'):
    rows = db.execute('SELECT * FROM ' + table + ' ORDER BY 1').fetchall()
    critical[table] = {'count': len(rows), 'SHA256': fingerprint(rows)}
result = {
    'bootID': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
    'pvc': meta(pvc), 'pv': meta(pv),
    'administrator': db.execute('SELECT id, created_at, updated_at FROM administrators ORDER BY id').fetchall(),
    'criticalTables': critical,
    'activeOperations': db.execute("SELECT count(*) FROM operations WHERE state NOT IN ('succeeded','failed')").fetchone()[0],
    'liveApplications': db.execute('SELECT id, name, version, desired_revision_id FROM applications WHERE deleted=0 ORDER BY id').fetchall(),
    'configurationSecrets': db.execute('SELECT count(*) FROM secrets').fetchone()[0],
    'registryCredentials': db.execute('SELECT count(*) FROM registry_credentials').fetchone()[0],
    'applicationVolumes': db.execute('SELECT count(*) FROM volumes WHERE deleted=0').fetchone()[0],
}
db.close()
platform = get('deployment', 'platform')
result['platformDeployment'] = {'metadata': meta(platform), 'spec': platform['spec']}
result['platformPods'] = [
    {'metadata': meta(p), 'image': p['spec']['containers'][0]['image'],
     'imageID': p.get('status', {}).get('containerStatuses', [{}])[0].get('imageID'),
     'ready': all(c['ready'] for c in p.get('status', {}).get('containerStatuses', [])),
     'deleting': bool(p['metadata'].get('deletionTimestamp'))}
    for p in get('pods')['items']
    if p['metadata'].get('labels', {}).get('app.kubernetes.io/name') == 'platform'
]
for kind in ('deployments', 'services', 'ingresses'):
    result[kind] = [{'metadata': meta(x), 'spec': x['spec']} for x in get(kind, namespace='platform-apps')['items']]
secrets = get('secrets')['items']
result['tlsSecrets'] = [{**meta(x), 'dataSHA256': fingerprint(x.get('data', {}))} for x in secrets if x.get('type') == 'kubernetes.io/tls']
result['helmPlatformRevisions'] = sorted(x['metadata']['name'] for x in secrets
    if x.get('type') == 'helm.sh/release.v1' and x['metadata']['labels'].get('name') == 'platform')
result['lanConfigurationSHA256'] = hashlib.sha256(Path('/etc/k8s-internal-platform/private-lan.json').read_bytes()).hexdigest()
out = Path(sys.argv[1])
out.write_text(json.dumps(result, indent=2) + '\n')
out.chmod(0o600)
print('Whitelisted read-only retention snapshot written', flush=True)
