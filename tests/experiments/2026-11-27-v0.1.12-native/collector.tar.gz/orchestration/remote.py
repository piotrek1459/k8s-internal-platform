from pathlib import Path
import subprocess,json
ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/'ssh.json').read_text())
def command(script,timeout=60):
 return subprocess.run(['ssh','-S',CFG['control'],'-oBatchMode=yes',CFG['host'],'bash -s'],input=script,text=True,capture_output=True,timeout=timeout)
def upload(source,target):
 subprocess.run(['scp','-q','-oControlPath='+CFG['control'],str(source),CFG['host']+':'+target],check=True)
def download(source,target):
 subprocess.run(['scp','-q','-r','-oControlPath='+CFG['control'],CFG['host']+':'+source,str(target)],check=True)
