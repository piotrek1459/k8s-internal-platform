#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git rev-parse --show-toplevel)"
docker run --rm --add-host platform.home.arpa:192.168.68.227 --add-host demo.apps.home.arpa:192.168.68.227 --add-host web.apps.home.arpa:192.168.68.227 --add-host ghost.apps.home.arpa:192.168.68.227 --add-host renamed.apps.home.arpa:192.168.68.227 --add-host original.apps.home.arpa:192.168.68.227 --add-host failed.apps.home.arpa:192.168.68.227 \
  -v "$ROOT/tests/e2e:/repo/tests/e2e:ro" \
  -v "$ROOT/.local/pi-acceptance/native-v0112/client-state:/evidence" \
  -v "$ROOT/.local/pi-acceptance/native-v018/pki/ca.crt:/input/ca.crt:ro" \
  -v "$ROOT/.local/pi-acceptance/native-v0112/lan-client.py:/runner.py:ro" \
  platform-native-lan-client:1.64.1 python -B /runner.py "$1"
