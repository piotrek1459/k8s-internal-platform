import subprocess
for script,log in [('validate-defaults.py','defaults.log'),('published.py','published.log'),('retention.py','retention.log')]:
 with open(log,'w') as output:subprocess.run(['python3',script],stdout=output,stderr=subprocess.STDOUT,check=True)
print('NATIVE_SEQUENCE_COMPLETE',flush=True)
