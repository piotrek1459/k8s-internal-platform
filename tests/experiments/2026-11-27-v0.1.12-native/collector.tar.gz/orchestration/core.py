import sys,json,time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'tools')
from run import Experiment
from common import write_json
p=Path.cwd();args=SimpleNamespace(plan=p/'plan.json',release_manifest=p/'release.json',state=p/'access.json',ca=p/'ca.crt',management_url='https://platform.home.arpa:8443',address='192.168.68.227',chart=p/'embedded-chart',output=p/'core-01',kubeconfig='/etc/rancher/k3s/k3s.yaml',tools='/usr/local/lib/k8s-internal-platform')
e=Experiment(args);checks=[]
def record(text,**data):
 checks.append({'check':text,'epochSeconds':time.time(),**data});write_json(e.folder/'checks.json',checks);print(text,flush=True)
def https(version):
 end=time.monotonic()+60
 while True:
  try:
   with e.api.http.open('https://demo.apps.home.arpa:8443/version',timeout=3) as r:value=json.load(r)
   if value['version']==version:return value
  except Exception:pass
  if time.monotonic()>end:raise TimeoutError('Actual HTTPS did not converge')
  time.sleep(.2)
try:
 spec=e.spec('retained',lan=True);spec.pop('resources');spec['exposure']['hostname']='demo.apps.home.arpa'
 accepted=e.api.create(spec);app=accepted['applicationId'];e.owned['applications'][app]={'name':spec['name'],'operation':accepted['operationId']};e.save_owned();e.api.poll(accepted['operationId'])
 initial=e.api.get('/apps/'+app)['lastSuccessfulRevision'];https('v1')
 pods=e.host.app_pods(app);expected={'requests':{'cpu':'25m','memory':'48Mi'},'limits':{'cpu':'250m','memory':'128Mi'}}
 assert len(pods)==1 and pods[0]['spec']['containers'][0]['resources']==expected
 assert pods[0]['spec']['containers'][0]['lifecycle']=={'preStop':{'sleep':{'seconds':5}}}
 platform=e.host.kube('-n','platform-system','get','pods','-l','app.kubernetes.io/name=platform')['items'];assert len(platform)==1
 assert platform[0]['spec']['containers'][0]['image']==e.images['platform'] and platform[0]['status']['containerStatuses'][0]['imageID']==e.images['platform']
 private=e.host.kube('-n','platform-system','get','deployment','platform-private');args=private['spec']['template']['spec']['containers'][0]['args']
 assert args.count('--providers.kubernetesingress.nativelbbydefault=true')==1
 assert not any(x.startswith(('--api.insecure=','--providers.kubernetesingress.throttleduration=')) for x in args)
 record('Published private controller uses native Service routing without diagnostic or provider-delay overrides',privateDeploymentUID=private['metadata']['uid'],arguments=args)
 record('Omitted API resources rendered published 25m/48Mi requests, 250m/128Mi limits and native five-second drain; exact ARM64 broker image matched',app=app,resources=expected)
 a=e.api.mutate(app,'PATCH',image=e.images['v2']);e.api.poll(a['operationId']);https('v2')
 for n in (2,0,1):
  a=e.api.mutate(app,'PATCH',replicas=n);e.api.poll(a['operationId'])
  end=time.monotonic()+60
  while True:
   current=e.api.get('/apps/'+app);pods=e.host.app_pods(app)
   if current['status']['readyReplicas']==n and len(pods)==n:break
   if time.monotonic()>end:raise TimeoutError('Replica observation did not converge')
   time.sleep(.3)
 record('Published v2 update and stateless scaling 2/0/1 passed')
 before={r['metadata']['uid'] for r in e.host.app_pods(app)}
 a=e.api.mutate(app,'POST','/restart');e.api.poll(a['operationId']);https('v2');after={r['metadata']['uid'] for r in e.host.app_pods(app)}
 assert before.isdisjoint(after)
 assert e.api.get('/apps/'+app+'/revisions')['items'][0]['frozenImage']==e.images['v2']
 a=e.api.mutate(app,'POST','/rollback',revisionId=initial);e.api.poll(a['operationId']);https('v1')
 record('Digest-stable restart replaced Pods; explicit rollback restored actual HTTPS v1')
 current=e.api.get('/apps/'+app);state=json.loads((p/'access.json').read_text());state.update(retainedApp=app,retainedRevision=current['lastSuccessfulRevision']);write_json(p/'access.json',state)
 write_json(p/'retained-app.json',{'app':app,'application':current,'resources':expected,'coreChecks':checks})
 record('One healthy owned LAN application retained for repeated evaluation and persistence checks')
finally:e.close()
