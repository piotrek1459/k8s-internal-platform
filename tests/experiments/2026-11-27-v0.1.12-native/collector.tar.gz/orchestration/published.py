"""Acceptance of the unmodified published native installer and routing policy."""
import json,os,subprocess,sys,time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'tools')
from run import Experiment
from common import write_json

root=Path.cwd();exchange=root/'exchange';exchange.mkdir(mode=0o700,exist_ok=True);os.chown(exchange,1000,1000)
def experiment(name):
    return Experiment(SimpleNamespace(plan=root/'plan.json',release_manifest=root/'release.json',state=root/'access.json',ca=root/'ca.crt',management_url='https://platform.home.arpa:8443',address='192.168.68.227',chart=root/'embedded-chart',output=root/name,kubeconfig='/etc/rancher/k3s/k3s.yaml',tools='/usr/local/lib/k8s-internal-platform'))
def actual(e,url,version=None,text=None):
    end=time.monotonic()+60;observations=[]
    while True:
        try:
            with e.api.http.open(url,timeout=3) as r:body=r.read(1<<20);status=r.code
            ok=status==200 and (version is None or json.loads(body)['version']==version) and (text is None or text.encode() in body)
        except Exception as error:status=type(error).__name__;ok=False
        observations.append({'epochSeconds':time.time(),'status':status,'expected':ok})
        if ok:return observations
        if time.monotonic()>end:raise TimeoutError('HTTPS convergence exceeded its budget')
        time.sleep(.2)
def create(e,name,version='v1',public=False):
    image=e.plan['publicImage'] if public else e.images[version]
    app,op=e.api_create(name,image=image,lan=True,public=public);e.api.poll(op['operationId'])
    detail=e.api.get('/apps/'+app);url=detail['access']['url']+('' if public else 'version')
    observations=actual(e,url,version=None if public else version,text='Welcome to nginx!' if public else None)
    service=e.host.kube('-n','platform-apps','get','services','-l','platform.local/app-id='+app)['items'][0]
    write_json(e.folder/'fixture.json',{'appID':app,'url':url,'application':detail,'serviceUID':service['metadata']['uid'],'serviceSpec':service['spec'],'initialHTTPS':observations})
    private=e.host.kube('-n','platform-system','get','deployment','platform-private')
    args=private['spec']['template']['spec']['containers'][0]['args']
    assert args.count('--providers.kubernetesingress.nativelbbydefault=true')==1
    assert not any(x.startswith(('--api.insecure=','--providers.kubernetesingress.throttleduration=')) for x in args)
    write_json(e.folder/'private-policy.json',{'UID':private['metadata']['uid'],'arguments':args})
    return app,url
def job(name,url,seconds,rate=5,warmup=0,versions=('v1','v2'),policies=('pooled','fresh'),public=False,management=False):
    start=time.time()+12
    value={'jobID':name,'url':url,'startEpochSeconds':start,'seconds':seconds,'rate':rate,'warmup':warmup,'versions':versions,'policies':policies,'public':public,'management':management}
    write_json(exchange/'job.json',value);os.chown(exchange/'job.json',1000,1000)
    print('JOB',name,flush=True);return start
def receipts(e,name,policies,management=False):
    results={}
    for policy in (*policies,*(('management',) if management else ())):
        path=exchange/(name+'-'+policy+'-summary.json');end=time.monotonic()+45
        while not path.exists():
            if time.monotonic()>end:raise RuntimeError('Separate-client receipt missing')
            time.sleep(.2)
        result=json.loads(path.read_text());write_json(e.folder/(policy+'-summary.json'),result)
        assert result['complete'] and result['clientSchedulingValid']
        if policy!='management':assert result['targetsPassed'],'Observed application request or latency target failed'
        results[policy]=result
    return results
def retire(e,app,old):
    end=time.monotonic()+90
    while any(p['metadata']['uid'] in old for p in e.host.app_pods(app,include_deleting=True)):
        if time.monotonic()>end:raise TimeoutError('Previous Pods did not retire')
        time.sleep(.25)
    return time.time()
def finish(e,app,result):
    e.api_delete(app);assert e.application_identities()==e.original_apps
    result.update(originalApplicationsRetained=True,owned=e.owned)
    write_json(e.folder/'summary.json',result)

for repetition in range(1,4):
    name='routing-'+str(repetition);e=experiment(name)
    try:
        app,url=create(e,'routing');initial=e.api.get('/apps/'+app)['lastSuccessfulRevision'];start=job(name,url,55);timeline=[]
        for offset,action,expected in ((10,'update','v2'),(25,'rollback','v1'),(40,'restart','v1')):
            time.sleep(max(0,start+offset-time.time()));old={p['metadata']['uid'] for p in e.host.app_pods(app)};assert old
            entry={'action':action,'submitted':time.time(),'oldPodUIDs':sorted(old)}
            if action=='update':accepted=e.api.mutate(app,'PATCH',image=e.images['v2'])
            elif action=='rollback':accepted=e.api.mutate(app,'POST','/rollback',revisionId=initial)
            else:accepted=e.api.mutate(app,'POST','/restart')
            e.api.poll(accepted['operationId']);entry.update(ready=time.time(),operationID=accepted['operationId'])
            assert entry['ready']-entry['submitted']<=30
            entry['retired']=retire(e,app,old);entry['HTTPS']=actual(e,url,version=expected);timeline.append(entry);write_json(e.folder/'timeline.json',timeline)
        time.sleep(max(0,start+59-time.time()));results=receipts(e,name,('pooled','fresh'));finish(e,app,{'passed':True,'clients':results,'actions':timeline})
        print('ROUTING_PASS',repetition,flush=True)
    finally:e.close()

name='broker-continuity';e=experiment(name)
try:
    app,url=create(e,'broker');start=job(name,url,75,management=True);timeline=[]
    time.sleep(max(0,start+15-time.time()));accepted=e.api.mutate(app,'PATCH',image=e.images['v2']);e.api.poll(accepted['operationId']);timeline.append({'stage':'update-ready','epochSeconds':time.time()})
    time.sleep(max(0,start+35-time.time()));pods=e.host.kube('-n','platform-system','get','pods','-l','app.kubernetes.io/name=platform')['items'];assert len(pods)==1
    pod=pods[0];uid=pod['metadata']['uid'];timeline.append({'stage':'broker-delete-submitted','epochSeconds':time.time(),'oldPodUID':uid})
    body=json.dumps({'apiVersion':'v1','kind':'DeleteOptions','preconditions':{'uid':uid}})
    r=subprocess.run([e.host.kubectl,'--kubeconfig',e.host.kubeconfig,'delete','--raw','/api/v1/namespaces/platform-system/pods/'+pod['metadata']['name'],'-f','-'],input=body,text=True,capture_output=True,timeout=30);assert r.returncode==0
    end=time.monotonic()+120
    while True:
        pods=e.host.kube('-n','platform-system','get','pods','-l','app.kubernetes.io/name=platform')['items'];ready=[p for p in pods if p['metadata']['uid']!=uid and not p['metadata'].get('deletionTimestamp') and p['status'].get('containerStatuses') and all(c['ready'] for c in p['status']['containerStatuses'])]
        if len(ready)==1:
            try:
                assert not e.api.get('/apps/'+app)['activeOperationId'];break
            except (RuntimeError,TimeoutError):pass
        if time.monotonic()>end:raise TimeoutError('Broker replacement/session did not recover')
        time.sleep(.25)
    timeline.append({'stage':'broker-ready-original-session-valid','epochSeconds':time.time(),'newPodUID':ready[0]['metadata']['uid']});write_json(e.folder/'timeline.json',timeline)
    time.sleep(max(0,start+79-time.time()));results=receipts(e,name,('pooled','fresh'),management=True);finish(e,app,{'passed':True,'clients':results,'timeline':timeline})
    print('BROKER_CONTINUITY_PASS',flush=True)
finally:e.close()
write_json(root/'routing-complete.json',{'passed':True,'routingTrials':3,'brokerReplacement':True})

for workload in ('go','nginx'):
    name='steady-'+workload;e=experiment(name)
    try:
        public=workload=='nginx';app,url=create(e,'steady',public=public);before=e.host.containers(app);start=job(name,url,60,rate=20,warmup=10,versions=('v1',),policies=('pooled',),public=public)
        time.sleep(max(0,start+74-time.time()));results=receipts(e,name,('pooled',));after=e.host.containers(app)
        assert {c['containerID'] for c in before}=={c['containerID'] for c in after}
        for c in after:
            c['memoryPeakBytes']=int((Path(c['cgroup'])/'memory.peak').read_text());c['oomKills']=dict(line.split() for line in (Path(c['cgroup'])/'memory.events').read_text().splitlines())['oom_kill'];assert int(c['oomKills'])==0 and c['restartCount']==0
        finish(e,app,{'passed':True,'clients':results,'containersBefore':before,'containersAfter':after});print('STEADY_PASS',workload,flush=True)
    finally:e.close()

name='unhealthy-restoration';e=experiment(name)
try:
    app,url=create(e,'failure',version='v2');successful=e.api.get('/apps/'+app)['lastSuccessfulRevision'];start=job(name,url,330,rate=1,versions=('v2',));time.sleep(max(0,start+10-time.time()));submitted=time.time()
    accepted=e.api.mutate(app,'PATCH',image=e.images['v3']);op,states=e.api.poll(accepted['operationId'],expected='failed',budget=390);restored=time.time();assert op['stage']=='restored' and 300<=restored-submitted<=360
    current=e.api.get('/apps/'+app);assert not current['activeOperationId'] and current['lastSuccessfulRevision']==successful;actual(e,url,version='v2')
    write_json(e.folder/'operation.json',op);write_json(e.folder/'timing.json',{'submitted':submitted,'restored':restored,'failurePolicySeconds':300,'elapsedSeconds':restored-submitted,'states':states})
    time.sleep(max(0,start+334-time.time()));results=receipts(e,name,('pooled','fresh'));finish(e,app,{'passed':True,'clients':results,'verifiedRestoration':True});print('RESTORATION_PASS',flush=True)
finally:e.close()
write_json(root/'validation-complete.json',{'passed':True,'humanTrialStatus':'pending'})
print('PUBLISHED_ACCEPTANCE_COMPLETE',flush=True)
