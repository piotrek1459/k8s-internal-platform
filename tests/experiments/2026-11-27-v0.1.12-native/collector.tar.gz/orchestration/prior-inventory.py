from pathlib import Path
import sys,json,sqlite3,time
sys.path.insert(0,'tools')
from host import Host
from api import API
from common import write_json
p=Path.cwd();h=Host();expected=json.loads((p/'expected-old.json').read_text())
a=API('https://platform.home.arpa:8443',p/'old-access.json',p/'ca.crt','192.168.68.227','0.1.11')
try:
 a.login();apps=[a.get('/apps/'+r['id']) for r in a.get('/apps')['items']]
 assert len(apps)==1 and apps[0]['id']==expected['originalApp']['id']
 for k in ('version','desiredRevision','lastSuccessfulRevision','activeOperationId'):assert apps[0][k]==expected['originalApp'][k]
 assert not a.get('/secrets')['items'] and not a.get('/registry-credentials')['items']
 with a.http.open(apps[0]['access']['url']+'version',timeout=10) as r:assert json.load(r)['version']=='v1'
 names={x['metadata']['name'] for x in h.kube('get','namespaces')['items']};assert names=={'default','kube-system','kube-public','kube-node-lease','platform-system','platform-apps'}
 dep=h.kube('-n','platform-system','get','deployment','platform');assert dep['metadata']['uid']==expected['platformDeploymentUID']
 pvc=h.kube('-n','platform-system','get','pvc','platform-metadata');pv=h.kube('get','pv',pvc['spec']['volumeName'])
 assert len(h.kube('get','pvc','--all-namespaces')['items'])==len(h.kube('get','pv')['items'])==1
 result={'checkedEpochSeconds':time.time(),'applications':apps,'platformDeploymentUID':dep['metadata']['uid'],'pvc':pvc['metadata']['uid'],'pv':pv['metadata']['uid'],'resources':{},'host':h.facts()}
 for kind in ('deployments','daemonsets','statefulsets','jobs','cronjobs','pods','replicasets','services','ingresses','secrets','configmaps'):
  rows=h.kube('get',kind,'--all-namespaces')['items']
  for row in rows:
   ns=row['metadata']['namespace'];name=row['metadata']['name']
   if ns in {'default','kube-public','kube-node-lease'}:
    assert kind=='configmaps' and name=='kube-root-ca.crt' or kind=='services' and name=='kubernetes'
   if kind in ('daemonsets','statefulsets','jobs','cronjobs'):assert not rows
   if ns=='platform-apps':
    if kind=='secrets':assert row['type']=='helm.sh/release.v1' and row['metadata']['labels']['name']=='app-'+apps[0]['id'].replace('_','-')
    elif kind=='configmaps':assert name=='kube-root-ca.crt'
    elif kind in ('deployments','services','ingresses','pods','replicasets'):assert row['metadata']['labels']['platform.local/app-id']==apps[0]['id']
   if ns=='platform-system' and kind=='secrets':assert row['type'] in ('helm.sh/release.v1','kubernetes.io/tls')
  result['resources'][kind]=[{'metadata':{k:r['metadata'].get(k) for k in ('namespace','name','uid','labels','ownerReferences')},**({'spec':r['spec']} if kind in ('deployments','services','ingresses') else {})} for r in rows]
 folder=Path(pv['spec'].get('hostPath',pv['spec'].get('local',{}))['path']);files=list(folder.glob('*.db'));assert len(files)==1
 db=sqlite3.connect('file:'+str(files[0])+'?mode=ro',uri=True)
 assert db.execute('select count(*) from applications where active_operation_id is not null').fetchone()[0]==0
 for table in ('secrets','registry_credentials','volumes'):assert db.execute('select count(*) from '+table).fetchone()[0]==0
 rows=db.execute('select id,name from applications where deleted=0').fetchall();assert len(rows)==1 and rows[0][0]==apps[0]['id']
 result['database']={'activeApplications':rows,'administrators':db.execute('select id,created_at from administrators').fetchall(),'pendingOperations':0,'configurationSecrets':0,'registryCredentials':0,'applicationVolumes':0}
 write_json(p/'prior-inventory.json',result)
 print('Verified exclusive owned acceptance installation; no user applications, app volumes or credentials found')
finally:a.close()
