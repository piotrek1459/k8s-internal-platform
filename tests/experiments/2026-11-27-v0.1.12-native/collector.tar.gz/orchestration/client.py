"""Separate, bounded, normally verified clients; credentials are not inputs."""
import http.client,json,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,'tests/evaluation')
from load import run
from remote import command,upload
p=Path(__file__).resolve().parent
if len(sys.argv)>1 and sys.argv[1]=='worker':
    policy=sys.argv[2];job=json.loads(sys.argv[3])
    if policy=='fresh':
        original=http.client.HTTPSConnection.request
        def request(self,method,url,body=None,headers=None,*,encode_chunked=False):
            return original(self,method,url,body=body,headers={**(headers or {}),'Connection':'close'},encode_chunked=encode_chunked)
        http.client.HTTPSConnection.request=request
    url='https://platform.home.arpa:8443/readyz' if policy=='management' else job['url']
    result=run(url,p/'client'/job['jobID']/policy,p.parent/'native-v018/pki/ca.crt','192.168.68.227',rate=job['rate'],seconds=job['seconds'],warmup=job['warmup'],expected_version=None if policy=='management' or job['public'] else tuple(job['versions']),expected_text='"status":"ready"' if policy=='management' else ('Welcome to nginx!' if job['public'] else None))
    upload(p/'client'/job['jobID']/policy/'summary.json','platform-v0.1.12/exchange/'+job['jobID']+'-'+policy+'-summary.json')
    print(job['jobID'],policy,result['successful'],result['requests'],result['targetsPassed'],flush=True);sys.exit(0)
seen=set();end=time.monotonic()+2700
while len(seen)<7:
    r=command('cat platform-v0.1.12/exchange/job.json 2>/dev/null')
    if r.returncode==0:
        job=json.loads(r.stdout)
        if job['jobID'] not in seen:
            delay=job['startEpochSeconds']-time.time()
            if delay>0:time.sleep(delay)
            assert time.time()-job['startEpochSeconds']<2,'Late client start'
            policies=[*job['policies'],*(('management',) if job['management'] else ())]
            children=[subprocess.Popen([sys.executable,str(Path(__file__)),'worker',policy,json.dumps(job)]) for policy in policies]
            for child in children:assert child.wait()==0
            seen.add(job['jobID'])
    if time.monotonic()>end:raise TimeoutError('Published acceptance jobs incomplete')
    time.sleep(1)
print('ALL_CLIENT_JOBS_COMPLETE',flush=True)
