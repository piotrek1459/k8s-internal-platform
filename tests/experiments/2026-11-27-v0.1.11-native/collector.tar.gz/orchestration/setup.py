import sys,os
from pathlib import Path
from types import SimpleNamespace
os.umask(0o077)
sys.path.insert(0,'tests/e2e')
from native import Native
p=Path('.local/pi-acceptance/native-v0111')
args=SimpleNamespace(url='http://127.0.0.1:8080',kubernetes_url='http://127.0.0.1:18001',version='v0.1.11',release_manifest=p/'release.json',state=p/'access.json',artifacts=p/'setup',setup=True)
n=Native(args);n.browser_setup();n.client.login();s=n.client.get('/system');assert s['version']=='0.1.11' and s['architecture']=='arm64' and s['clusterReachable'];n.client.request('DELETE','/auth/session')
print('Published ARM64 v0.1.11 initial browser setup/login passed')
