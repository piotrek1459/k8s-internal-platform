"""Reference-only direct LAN validation; contains no embedded credentials/keys."""
import http.cookiejar, json, os, secrets, ssl, subprocess, sys, time, urllib.request
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0, '/repo/tests/e2e')
from support import Client
from playwright.sync_api import sync_playwright, expect
P=Path('/evidence'); URL='https://platform.home.arpa:8443'; APP='https://demo.apps.home.arpa:8443/'
state=json.loads((P/'access.json').read_text()); phase=sys.argv[1]
os.umask(0o077)
records=[]
def record(text,**data):
    records.append({'check':text,**data}); (P/('lan-'+phase+'.json')).write_text(json.dumps(records,indent=2)+'\n'); print(text,flush=True)
def trust():
    db=Path.home()/'.local/share/pki/nssdb';db.mkdir(parents=True,exist_ok=True)
    commands=[] if (db/'cert9.db').exists() else [['-N','--empty-password']]
    commands.append(['-A','-t','C,,','-n','Reference Pi LAN CA','-i','/input/ca.crt'])
    for args in commands:
        subprocess.run(['certutil','-d','sql:'+str(db),*args],check=True,capture_output=True,timeout=30)
    record('Public CA imported into isolated Chromium NSS trust store; no certificate-ignore or SPKI flags')
context=ssl.create_default_context(cafile='/input/ca.crt')
e=SimpleNamespace(url=URL,password=state['password']);client=Client(e)
jar=http.cookiejar.LWPCookieJar(str(P/'lan-api-cookies.lwp'))
client.cookies=jar;client.http=urllib.request.build_opener(urllib.request.HTTPSHandler(context=context),urllib.request.HTTPCookieProcessor(jar))
def fetch(url):
    with urllib.request.urlopen(url,context=context,timeout=20) as r:return r.status,r.read()
def wait_http(url,version=None,contains=None):
    deadline=time.monotonic()+90;last=''
    while time.monotonic()<deadline:
        try:
            code,body=fetch(url)
            if code==200 and (version is None or json.loads(body)['version']==version) and (contains is None or contains in body):return
            last=str(code)
        except Exception as x:last=type(x).__name__
        time.sleep(1)
    raise AssertionError('Actual HTTPS did not converge: '+last)
def mutate(app,method,suffix='',**changes):
    return client.mutate(method,'/apps/'+app+suffix,{'version':client.get('/apps/'+app)['version'],**changes})
def snapshot():
    ids=[state['retainedApp'],json.loads((P/'lan-owned.json').read_text())['app']]
    return {'system':client.get('/system'),'apps':{a:client.get('/apps/'+a) for a in ids},'revisions':{a:client.get('/apps/'+a+'/revisions') for a in ids}}
def verify_identity(before,after):
    assert before['system']==after['system']
    assert before['revisions']==after['revisions']
    for app in before['apps']:
        for key in ('id','name','version','desiredRevision','lastSuccessfulRevision','activeOperationId','access'):
            assert before['apps'][app].get(key)==after['apps'][app].get(key),(app,key)
        assert after['apps'][app]['status']['phase']=='ready'
if phase in ('workflows','browser'):
    assert client.request('GET','/system')[0]==401
    with sync_playwright() as p:
        b=p.chromium.launch(args=['--no-proxy-server'])
        try:
            page=b.new_page(ignore_https_errors=False)
            try:page.goto(URL+'/login');raise AssertionError('Untrusted CA accepted')
            except Exception as exc:
                assert 'ERR_CERT_AUTHORITY_INVALID' in str(exc),type(exc).__name__
        finally:b.close()
    record('Direct LAN Chromium rejected the untrusted CA before any trust import')
    trust()
    if (P/'lan-api-cookies.lwp').exists():
        jar.load(ignore_discard=True,ignore_expires=True);client.request('DELETE','/auth/session');jar.clear()
    client.login();jar.save(ignore_discard=True,ignore_expires=True)
    assert all(c.secure and c._rest.get('HttpOnly') is None and not c.domain_specified for c in jar)
    sysinfo=client.get('/system');assert sysinfo['version']=='0.1.11' and sysinfo['architecture']=='arm64'
    assert sysinfo['privateNetwork']['managementHostname']=='platform.home.arpa'
    record('Direct LAN CA-verified HTTPS login and ARM64 release identity; unauthenticated system read refused')
    images=json.loads((P/'release.json').read_text())['targets']['arm64']['images']
    spec={'name':'native-lan-'+secrets.token_hex(3),'image':images['v1'],'containerPort':8080,'profile':'http',
          'health':{'startupPath':'/healthz','readinessPath':'/readyz'},'exposure':{'mode':'lan','hostname':'demo.apps.home.arpa'}}
    if phase=='workflows':
        if (P/'lan-owned.json').exists():
            app=json.loads((P/'lan-owned.json').read_text())['app'];current=client.get('/apps/'+app)
            assert current['id']==app and current['name'].startswith('eval-') and current['access']['mode'] in ('internal','lan')
            mutate(app,'PATCH',image=images['v1'],replicas=1,exposure={'mode':'lan','hostname':'demo.apps.home.arpa'})
        else:
            accepted,_=client.mutate('POST','/apps',spec);app=accepted['applicationId'];(P/'lan-owned.json').write_text(json.dumps({'app':app}))
        wait_http(APP+'version','v1');initial=next(r['id'] for r in client.get('/apps/'+app+'/revisions')['items'] if r['number']==1)
        record('Bundled digest-pinned v1 deployed and returned actual HTTPS v1 from the separate LAN workstation',application=app)
        for hostname in ('platform.home.arpa','apps.home.arpa','two.labels.apps.home.arpa','unrelated.example'):
            assert client.request('POST','/apps',{**spec,'name':'refused-'+secrets.token_hex(3),'exposure':{'mode':'lan','hostname':hostname}},{'Idempotency-Key':secrets.token_hex(16)})[0]==400
        count=len(client.get('/apps')['items'])
        assert client.request('POST','/apps',{**spec,'name':'duplicate-'+secrets.token_hex(3)},{'Idempotency-Key':secrets.token_hex(16)})[0]==409
        assert len(client.get('/apps')['items'])==count
        def expect_absent(host):
            observations=[];started=time.monotonic();deadline=started+30
            while time.monotonic()<deadline:
                try:code,body=fetch('https://'+host+':8443/version')
                except urllib.error.HTTPError as error:code=error.code
                observations.append({'secondsAfterOperation':round(time.monotonic()-started,3),'status':code})
                all_observations=json.loads((P/'route-absence-observations.json').read_text()) if (P/'route-absence-observations.json').exists() else {}
                all_observations[host]=observations;(P/'route-absence-observations.json').write_text(json.dumps(all_observations,indent=2)+'\n')
                if code==404:return
                time.sleep(.2)
            raise AssertionError('Removed hostname still serves traffic after bounded gateway convergence')
        mutate(app,'PATCH',exposure={'mode':'internal'})
        assert client.get('/apps/'+app)['access']['mode']=='internal'
        expect_absent('demo.apps.home.arpa')
        mutate(app,'PATCH',exposure={'mode':'lan','hostname':'renamed.apps.home.arpa'})
        wait_http('https://renamed.apps.home.arpa:8443/version','v1')
        assert client.get('/apps/'+app)['access']['url']=='https://renamed.apps.home.arpa:8443/'
        expect_absent('demo.apps.home.arpa')
        mutate(app,'PATCH',exposure={'mode':'lan','hostname':'demo.apps.home.arpa'})
        wait_http(APP+'version','v1');expect_absent('renamed.apps.home.arpa')
        record('Native tracked LAN-to-Internal, Internal-to-LAN and hostname changes returned actual HTTPS/404 with matching effective URLs')
        mutate(app,'PATCH',image=images['v2']);wait_http(APP+'version','v2')
        for n in (2,0,1):
            mutate(app,'PATCH',replicas=n)
            deadline=time.monotonic()+60
            while client.get('/apps/'+app)['status']['readyReplicas']!=n:
                assert time.monotonic()<deadline,'Observed replica count did not converge'
                time.sleep(1)
        mutate(app,'POST','/restart');wait_http(APP+'version','v2')
        mutate(app,'POST','/rollback',revisionId=initial);wait_http(APP+'version','v1')
        record('Actual LAN HTTPS v2 update, scale 2/0/1, restart and explicit rollback to v1 completed')
        (P/'api-lifecycle-complete').write_text(app)
    else:
        app=json.loads((P/'lan-owned.json').read_text())['app']
        assert client.get('/apps/'+app)['name'].startswith('eval-')
        wait_http(APP+'version','v1')
    with sync_playwright() as p:
        b=p.chromium.launch(args=['--no-proxy-server'])
        try:
            c=b.new_context(ignore_https_errors=False);page=c.new_page();page.set_default_timeout(60000)
            page.goto(URL+'/login');page.get_by_label('Password',exact=True).fill(state['password']);page.get_by_role('button',name='Sign in',exact=True).click();page.wait_for_url('**/apps')
            cookies=c.cookies(URL);assert len(cookies)==1
            assert cookies[0]['secure'] and cookies[0]['httpOnly'] and cookies[0]['sameSite']=='Strict'
            assert cookies[0]['domain']=='platform.home.arpa';assert c.cookies(APP)==[]
            page.goto(URL+'/apps/'+app);page.reload();expect(page.get_by_role('link',name=APP,exact=True)).to_have_attribute('href',APP)
            browser_observations=[];deadline=time.monotonic()+90
            while time.monotonic()<deadline:
                try:
                    response=page.goto(APP+'version',wait_until='commit',timeout=15000);body=response.json() if response.status==200 else {}
                except Exception as error:
                    browser_observations.append({'transportError':type(error).__name__})
                    (P/'browser-http-observations.json').write_text(json.dumps(browser_observations,indent=2)+'\n')
                    page.goto('about:blank',wait_until='commit');continue
                browser_observations.append({'status':response.status,'version':body.get('version')})
                (P/'browser-http-observations.json').write_text(json.dumps(browser_observations,indent=2)+'\n')
                if response.status==200 and body.get('version')=='v1':break
                time.sleep(1)
            else:raise AssertionError('Browser HTTPS did not converge to v1 within 90 seconds')
            (P/'browser-http-observations.json').write_text(json.dumps(browser_observations,indent=2)+'\n')
            cross=page.evaluate('''async u=>{try {await fetch(u+'/api/v1/auth/session',{method:'DELETE',credentials:'include',headers:{'X-Requested-With':'XMLHttpRequest'}});return 'allowed';}catch{return 'blocked';}}''',URL)
            assert cross=='blocked'
            page.goto(URL+'/apps/'+app);expect(page.get_by_role('link',name=APP,exact=True)).to_be_visible()
            c.storage_state(path=str(P/'lan-browser-state.json'))
            page.goto(URL+'/apps/new');page.get_by_label('Image reference').fill('docker.io/nginxinc/nginx-unprivileged:stable-alpine')
            with page.expect_response(lambda r:r.url.endswith('/api/v1/images/inspect') and r.request.method=='POST') as inspection:
                page.get_by_role('button',name='Inspect image',exact=True).click()
            assert inspection.value.status==200
            page.get_by_role('button',name='Next').click();page.get_by_label('Name',exact=True).fill('native-lan-browser-'+secrets.token_hex(3))
            page.get_by_label('Container port').fill('8080');page.get_by_label('Readiness path').fill('/');page.get_by_role('button',name='Next').click()
            page.locator('input[name="exposure"][value="lan"]').check();page.get_by_label('LAN hostname',exact=True).fill('web.apps.home.arpa')
            page.get_by_role('button',name='Next').click();page.get_by_role('button',name='Next').click()
            with page.expect_response(lambda r:r.url.endswith('/api/v1/apps') and r.request.method=='POST') as response:page.get_by_role('button',name='Deploy',exact=True).click()
            assert response.value.status==202;accepted=response.value.json();owned=json.loads((P/'lan-owned.json').read_text());owned['browserApp']=accepted['applicationId'];(P/'lan-owned.json').write_text(json.dumps(owned))
            client.poll(accepted['operationId']);web='https://web.apps.home.arpa:8443/'
            page.goto(URL+'/apps/'+accepted['applicationId']);page.reload();expect(page.get_by_role('link',name=web,exact=True)).to_have_attribute('href',web)
            wait_http(web,contains=b'Welcome to nginx!');page.goto(web);expect(page.get_by_role('heading',name='Welcome to nginx!')).to_be_visible()
            mutate(accepted['applicationId'],'DELETE');assert client.get('/apps/'+accepted['applicationId']+'/revisions')['items']
            record('Normally trusted Chromium login, host-only Secure/HttpOnly/Strict cookie, persisted app link, CORS/CSRF refusal and full Nginx UI deployment/HTTPS/deletion passed',browser=b.version)
        finally:b.close()
    (P/'lan-before-retention.json').write_text(json.dumps(snapshot(),indent=2))
else:
    trust();jar.load(ignore_discard=True,ignore_expires=True)
    before=json.loads((P/'lan-before-retention.json').read_text());after=snapshot();verify_identity(before,after)
    wait_http(APP+'version','v1')
    with sync_playwright() as p:
        b=p.chromium.launch(args=['--no-proxy-server'])
        try:
            c=b.new_context(ignore_https_errors=False,storage_state=str(P/'lan-browser-state.json'));page=c.new_page()
            app=json.loads((P/'lan-owned.json').read_text())['app'];page.goto(URL+'/apps/'+app);expect(page.get_by_role('link',name=APP,exact=True)).to_be_visible();assert '/login' not in page.url
        finally:b.close()
    record('Original HTTPS API session and browser session, administrator/system, retained application/revisions/history and actual HTTPS v1 survived '+phase)
    (P/('lan-after-'+phase+'.json')).write_text(json.dumps(after,indent=2))
    if phase=='cleanup':
        assert state['retainedApp']==app
        live=client.get('/apps/'+app);wait_http(APP+'version','v1')
        state.update(retainedRevision=live['lastSuccessfulRevision']);(P/'access.json').write_text(json.dumps(state))
        assert client.request('DELETE','/auth/session')[0]==204
        assert client.request('GET','/system')[0]==401
        cookies=json.loads((P/'lan-browser-state.json').read_text())['cookies']
        header='; '.join(x['name']+'='+x['value'] for x in cookies if x['domain']=='platform.home.arpa')
        assert header
        assert client.request('DELETE','/auth/session',headers={'Cookie':header})[0]==204
        assert client.request('GET','/system',headers={'Cookie':header})[0]==401
        for name in ('lan-api-cookies.lwp','lan-browser-state.json'):(P/name).unlink()
        record('One healthy LAN demo remains; saved API/browser sessions revoked and cookie files removed')
