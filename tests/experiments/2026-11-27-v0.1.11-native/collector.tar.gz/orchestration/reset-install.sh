#!/usr/bin/env bash
set -euo pipefail
umask 077
cd /home/piotrek/platform-v0.1.11
python3 - <<'PY'
import sys,json,time
from pathlib import Path
sys.path.insert(0,'tools')
from host import Host
h=Host();p=Path.cwd();before=json.loads((p/'prior-inventory.json').read_text())
d=h.kube('-n','platform-system','get','deployment','platform');assert d['metadata']['uid']==before['platformDeploymentUID']
assert not h.kube('-n','platform-apps','get','pvc')['items']
h.command([h.kubectl,'--kubeconfig',h.kubeconfig,'-n','platform-system','scale','deployment/platform','--replicas=0'])
end=time.monotonic()+90
while h.kube('-n','platform-system','get','pods','-l','app.kubernetes.io/name=platform')['items']:
 if time.monotonic()>end:raise TimeoutError('Metadata writer did not stop; reset aborted')
 time.sleep(.5)
print('Owned metadata writer stopped before archive')
PY
systemctl stop k3s
if systemctl is-active --quiet k3s; then exit 1; fi
tar -C / -czpf previous-v0.1.10.tar.gz var/lib/rancher/k3s/server var/lib/rancher/k3s/storage etc/rancher/k3s etc/k8s-internal-platform usr/local/lib/k8s-internal-platform
chmod 600 previous-v0.1.10.tar.gz
gzip -t previous-v0.1.10.tar.gz
sha256sum previous-v0.1.10.tar.gz > archive-sha256.txt
/usr/local/bin/k3s-uninstall.sh > owned-uninstall.log 2>&1
mv /etc/k8s-internal-platform previous-state-root
mv /usr/local/lib/k8s-internal-platform previous-tools-root
bash install.sh --version v0.1.11 --check > fresh-check.log 2>&1
bash install.sh --version v0.1.11 --bundle platform-v0.1.11-linux-arm64.tar.gz --checksum SHA256SUMS > fresh-install.log 2>&1
bash install.sh --version v0.1.11 --check > installed-check.log 2>&1
printf 'FRESH_PUBLISHED_INSTALL_CHECKS_PASSED\n'
