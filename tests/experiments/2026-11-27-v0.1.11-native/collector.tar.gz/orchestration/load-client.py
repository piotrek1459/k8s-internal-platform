import sys,json,time
from pathlib import Path
sys.path.insert(0,'tests/evaluation')
from load import run
from remote import command as remote,upload
folder=Path('.local/pi-acceptance/native-v0111/client');folder.mkdir(mode=0o700,exist_ok=True)
seen=set();deadline=time.monotonic()+4500
while len(seen)<6 and time.monotonic()<deadline:
    result=remote('cat platform-v0.1.11/exchange/job.json 2>/dev/null')
    if result.returncode:time.sleep(2);continue
    job=json.loads(result.stdout)
    if job['jobID'] in seen:time.sleep(2);continue
    wait=job['startEpochSeconds']-time.time()
    if wait< -2:raise RuntimeError('Client missed the predefined idle/load boundary')
    if wait>0:time.sleep(wait)
    if time.time()-job['startEpochSeconds']>2:raise RuntimeError('Late load start; no mismatched sample accepted')
    target=folder/job['jobID']
    result=run(job['url'],target,Path('.local/pi-acceptance/native-v018/pki/ca.crt'),'192.168.68.227',
               rate=job['rate'],seconds=job['seconds'],warmup=job['warmup'],timeout=3,
               expected_version=None if job['workload']=='nginx' else 'v1',expected_text='Welcome to nginx!' if job['workload']=='nginx' else None, workers=job['workers'])
    upload(target/'summary.json','platform-v0.1.11/exchange/'+job['jobID']+'-summary.json')
    seen.add(job['jobID']);print(job['jobID'],json.dumps({'requests':result['requests'],'successRate':result['successRate'],'p95':result['latencyMilliseconds']['p95'],'passed':result['targetsPassed']}),flush=True)
print('LOAD_CLIENT_DONE',sorted(seen),flush=True)
