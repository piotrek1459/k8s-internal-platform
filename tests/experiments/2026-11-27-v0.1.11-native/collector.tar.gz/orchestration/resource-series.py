"""Reference-run coordinator; root sampling, separate verified client, owned cleanup."""
import sys,json,time,threading,traceback,os
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'tools')
from run import Experiment
from host import sample
from common import write_json
root=Path.cwd();exchange=root/'exchange';exchange.mkdir(mode=0o700,exist_ok=True);os.chown(exchange,1000,1000)
end=time.monotonic()+2700
while not (root/'lifecycle-01/summary.json').exists():
    if time.monotonic()>end:raise TimeoutError('Lifecycle result absent; no overlapping resource run started')
    time.sleep(2)
life=json.loads((root/'lifecycle-01/summary.json').read_text())
if not life['acceptance']['passed']:raise RuntimeError('Lifecycle failed its declared targets; resource run not started')
for repetition in range(1,4):
    for workload in (('go','nginx') if repetition%2 else ('nginx','go')):
        name=f'{workload}-{repetition}';folder=root/'resources'/name
        args=SimpleNamespace(plan=root/'plan.json',release_manifest=root/'release.json',state=root/'access.json',ca=root/'ca.crt',
            management_url='https://platform.home.arpa:8443',address='192.168.68.227',chart=root/'embedded-chart',output=folder,
            kubeconfig='/etc/rancher/k3s/k3s.yaml',tools='/usr/local/lib/k8s-internal-platform')
        exp=Experiment(args)
        try:
            public=workload=='nginx';image=exp.plan['publicImage'] if public else exp.images['v1']
            app,accepted=exp.api_create('load',image=image,lan=True,public=public)
            exp.api.poll(accepted['operationId'],budget=exp.plan['operationDeadlineSeconds'])
            current=exp.api.get('/apps/'+app)
            write_json(folder/'fixture.json',{'appID':app,'image':image,'access':current['access'],'workload':workload,'repetition':repetition})
            results={}
            def sampling():
                try:results['sampler']=sample(exp.host,app,folder/'host',seconds=110,interval=1)
                except BaseException as error:results['error']=type(error).__name__
            thread=threading.Thread(target=sampling);thread.start()
            deadline=time.monotonic()+30
            while not (folder/'host/ready.json').exists():
                if time.monotonic()>deadline or 'error'in results:raise RuntimeError('Sampler did not start')
                time.sleep(.1)
            ready=json.loads((folder/'host/ready.json').read_text())
            job={'jobID':name,'url':current['access']['url']+('' if public else 'version'),'startEpochSeconds':ready['startedEpochSeconds']+30,
                 'workload':workload,'repetition':repetition,'rate':20,'seconds':60,'warmup':10,'workers':exp.plan['maximumOutstandingRequests']}
            write_json(exchange/'job.json',job);os.chown(exchange/'job.json',1000,1000)
            print('LOAD_JOB',name,flush=True)
            thread.join()
            deadline=time.monotonic()+30
            receipt=exchange/(name+'-summary.json')
            while not receipt.exists() and time.monotonic()<deadline:time.sleep(.5)
            if not receipt.exists():raise RuntimeError('Separate-client result absent')
            observed=json.loads(receipt.read_text());write_json(folder/'client-summary.json',observed)
            if not results.get('sampler',{}).get('evidenceValid') or not observed['targetsPassed']:
                raise RuntimeError('Resource/request evidence incomplete or a target failed')
            exp.api_delete(app)
            write_json(folder/'complete.json',{'passed':True,'originalApplicationsRetained':exp.application_identities()==exp.original_apps,'owned':exp.owned})
            print('RESOURCE_COMPLETE',name,flush=True)
        except BaseException:
            traceback.print_exc();raise
        finally:exp.close()
write_json(root/'resources/complete.json',{'runs':6,'complete':True,'humanOperatorTime':None})
print('RESOURCE_SERIES_COMPLETE',flush=True)
