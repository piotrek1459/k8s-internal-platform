"""Final real-cluster audit of the reference installation and owned test cleanup."""
import json
import sys
from pathlib import Path

sys.path.insert(0, 'tools')
from api import API
from common import write_json
from host import Host

root = Path.cwd()
state = json.loads((root / 'access.json').read_text())
release = json.loads((root / 'release.json').read_text())
images = release['targets']['arm64']['images']
host = Host('/etc/rancher/k3s/k3s.yaml', '/usr/local/lib/k8s-internal-platform')
api = API('https://platform.home.arpa:8443', root / 'access.json', root / 'ca.crt', '192.168.68.227', '0.1.11')
try:
    system = api.login()
    apps = api.get('/apps')['items']
    assert len(apps) == 1 and apps[0]['id'] == state['retainedApp']
    app = api.get('/apps/' + apps[0]['id'])
    assert app['version'] == 7 and app['lastSuccessfulRevision'] == state['retainedRevision']
    assert app['status']['phase'] == 'ready' and app['activeOperationId'] is None
    assert api.get('/secrets')['items'] == [] and api.get('/registry-credentials')['items'] == []
    with api.http.open(app['access']['url'] + 'version', timeout=10) as response:
        assert response.code == 200 and json.load(response)['version'] == 'v1'
    pods = host.kube('-n', 'platform-system', 'get', 'pods', '-l', 'app.kubernetes.io/name=platform')['items']
    assert len(pods) == 1 and not pods[0]['metadata'].get('deletionTimestamp')
    assert pods[0]['spec']['containers'][0]['image'] == images['platform']
    assert pods[0]['status']['containerStatuses'][0]['ready']
    assert pods[0]['status']['containerStatuses'][0]['imageID'] == images['platform']
    objects = {}
    for kind in ('deployments', 'services', 'ingresses', 'pods'):
        rows = host.kube('-n', 'platform-apps', 'get', kind)['items']
        assert len(rows) == 1 and rows[0]['metadata']['labels'].get('platform.local/app-id') == app['id'], kind
        objects[kind] = [{'name': x['metadata']['name'], 'uid': x['metadata']['uid']} for x in rows]
    assert host.kube('-n', 'platform-apps', 'get', 'pvc')['items'] == []
    stored = host.kube('-n', 'platform-apps', 'get', 'secrets')['items']
    assert all(x['type'] == 'helm.sh/release.v1' and x['metadata'].get('labels', {}).get('name') == 'app-' + app['id'].replace('_', '-') for x in stored)
    for pod in host.kube('get', 'pods', '-A')['items']:
        if pod.get('status', {}).get('phase') == 'Succeeded':
            continue
        assert any(c['type'] == 'Ready' and c['status'] == 'True' for c in pod.get('status', {}).get('conditions', [])), pod['metadata']['name']
    snapshot = json.loads((root / 'kube-after-reboot.json').read_text())
    assert all(snapshot[k] == 0 for k in ('activeOperations', 'configurationSecrets', 'registryCredentials', 'applicationVolumes'))
    write_json(root / 'final-audit.json', {'passed': True, 'release': '0.1.11',
        'system': system, 'platformImage': images['platform'], 'application': app,
        'applicationResources': objects, 'retainedApplications': 1, 'activeOperations': 0,
        'configurationSecrets': 0, 'registryCredentials': 0, 'applicationVolumes': 0,
        'remainingBenchmarkFixtures': 0, 'allNoncompletedPodsReady': True,
        'actualHTTPSVersion': 'v1', 'humanTrialStatus': 'pending'})
    print('FINAL_AUDIT_PASSED', flush=True)
finally:
    api.close()
