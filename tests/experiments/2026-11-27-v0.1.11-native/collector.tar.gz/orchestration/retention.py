import json,subprocess,time,sys
from pathlib import Path
root=Path.cwd();deadline=time.monotonic()+5400
while not (root/'default-validation-01/summary.json').exists():
 if time.monotonic()>deadline:raise TimeoutError('Native defaults validation did not finish')
 time.sleep(2)
def run(args,log=None):
 with open(log,'w') if log else open('/dev/null','w') as output:
  result=subprocess.run(args,stdout=output,stderr=subprocess.STDOUT)
 if result.returncode:raise RuntimeError('Retention prerequisite failed: '+args[0])
run(['python3','snapshot.py','kube-before-retention.json'])
run(['bash','install.sh','--version','v0.1.11','--bundle','platform-v0.1.11-linux-arm64.tar.gz','--checksum','SHA256SUMS'],'same-version-install.log')
run(['bash','install.sh','--version','v0.1.11','--check'],'same-version-check.log')
run(['python3','snapshot.py','kube-after-reinstall.json'])
before=json.loads((root/'kube-before-retention.json').read_text());after=json.loads((root/'kube-after-reinstall.json').read_text())
keys=['pvc','pv','administrator','criticalTables','liveApplications','platformDeployment','deployments','services','ingresses','tlsSecrets','lanConfigurationSHA256']
assert all(before[k]==after[k] for k in keys),'Retained metadata/spec/critical database identity changed'
assert len(after['platformPods'])==1 and after['platformPods'][0]['ready']
assert before['bootID']==after['bootID']
assert after['activeOperations']==0 and after['configurationSecrets']==0 and after['registryCredentials']==0 and after['applicationVolumes']==0
result={'passed':True,'sameVersionInstallerExit':0,'installedCheckExit':0,'lanConfigArgumentOmitted':True,'identicalFields':keys,'bootIDUnchanged':True}
(root/'reinstall-result.json').write_text(json.dumps(result,indent=2)+'\n')
print('SAME_VERSION_REINSTALL_COMPLETE',flush=True)
