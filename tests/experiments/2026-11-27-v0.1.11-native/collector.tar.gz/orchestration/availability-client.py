import sys,time,json,subprocess
from pathlib import Path
from remote import command as remote,upload
root=Path('.local/pi-acceptance/native-v0111/availability-client');root.mkdir(mode=0o700,exist_ok=True)
deadline=time.monotonic()+5400
while time.monotonic()<deadline:
 r=remote('cat platform-v0.1.11/exchange-availability/job.json 2>/dev/null')
 if r.returncode:time.sleep(2);continue
 job=json.loads(r.stdout);break
else:raise TimeoutError('Availability job absent')
wait=job['startEpochSeconds']-time.time()
if wait< -2:raise RuntimeError('Missed availability start')
if wait>0:time.sleep(wait)
if time.time()-job['startEpochSeconds']>2:raise RuntimeError('Client resumed after bounded availability start')
processes=[]
for name,url,expected in [('app',job['url'],['--versions','v1','v2']),('management',job['managementURL'],['--contains','"status":"ready"'])]:
 log=(root/(name+'.log')).open('w')
 command=[sys.executable,'tests/evaluation/load.py','--url',url,'--ca','.local/pi-acceptance/native-v018/pki/ca.crt','--address','192.168.68.227','--rate',str(job['rate']),'--seconds',str(job['seconds']),'--warmup','0','--output',str(root/name),*expected]
 processes.append((name,subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT),log))
for name,process,log in processes:
 process.wait();log.close()
 path=root/name/'summary.json'
 if not path.exists():raise RuntimeError('Availability trace incomplete')
 upload(path,'platform-v0.1.11/exchange-availability/'+name+'-summary.json')
 print(name,json.loads(path.read_text())['successRate'],flush=True)
